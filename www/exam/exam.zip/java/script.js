//  script d'acctualisation tout les 2 secoundes 

setInterval(function(){
window.location.reload();
},2000);
